// Gom dữ liệu JSON thành RawGameData. Phải qua createGameData / tryCreateGameData (@core) để
// kiểm tra trước khi dùng.

import type { RawGameData } from '@core'
import config from './balance.json'
import elements from './elements.json'
import items from './items.json'
import races from './races.json'
import skills from './skills.json'
import species from './species.json'
import traits from './traits.json'
import biomes from './biomes.json'
import statuses from './statuses.json'
import fieldEffects from './fieldEffects.json'
import textConfig from './i18n/config.json'

// Mỗi ngôn ngữ là một folder i18n/<mã>/ (language.json + một file cho mỗi loại nội dung). Tự tìm
// mọi folder để thêm ngôn ngữ chỉ cần thêm file (mục "Đa ngôn ngữ"); thiếu / thừa file hay id thì
// createGameData báo lỗi.
const textFiles = import.meta.glob<unknown>('./i18n/*/*.json', { eager: true, import: 'default' })

function collectLanguages(): Record<string, Record<string, unknown>> {
  const languages: Record<string, Record<string, unknown>> = {}
  for (const [path, value] of Object.entries(textFiles)) {
    const match = /^\.\/i18n\/([^/]+)\/([^/]+)\.json$/.exec(path)
    if (!match) continue
    const [, language, file] = match
    languages[language] ??= { content: {} }
    if (file === 'language') Object.assign(languages[language], value)
    else (languages[language].content as Record<string, unknown>)[file] = value
  }
  return languages
}

// JSON được suy kiểu rộng (ví dụ kind: string), nên ép kiểu ở đây; createGameData kiểm tra lại toàn bộ.
export const rawGameData = {
  config,
  elements,
  races,
  species,
  traits,
  skills,
  items,
  biomes,
  statuses,
  fieldEffects,
  text: { ...textConfig, languages: collectLanguages() }
} as unknown as RawGameData
